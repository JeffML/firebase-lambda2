const quick = require('./firebaseTest').quickstart
quick().then(() =>
  console.log('done')
);
